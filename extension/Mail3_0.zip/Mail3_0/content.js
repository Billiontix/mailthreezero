/*
  TODO: API call to fetch user public key
  TODO: if no public key, show Welcome message
  TODO: set public key by generating random phrases -> private key -> public key
  TODO: set loading message when encrypting message
  TODO: Check recipients' public keys via API call
  TODO: Add Splash Page with link to Download plugin
  TODO: Deploy Plugin to Chrome Plugin Store
  TODO: Add custom blockchain logic
  TODO: Add blockchain explorer on main website
  TODO: Add html for onboarding sequence
  TODO: detect encrypted message and offer to decrypt
*/

const headers = {
  'Content-Type': 'application/json'
};

const WORDS = [
  "abandon",
  "ability",
  "able",
  "about",
  "above",
  "absent",
  "absorb",
  "abstract",
  "absurd",
  "abuse",
  "access",
  "accident",
  "account",
  "accuse",
  "achieve",
  "acid",
  "acoustic",
  "acquire",
  "across",
  "act",
  "action",
  "actor",
  "actress",
  "actual",
  "adapt",
  "add",
  "addict",
  "address",
  "adjust",
  "admit",
  "adult",
  "advance",
  "advice",
  "aerobic",
  "affair",
  "afford",
  "afraid",
  "again",
  "age",
  "agent",
  "agree",
  "ahead",
  "aim",
  "air",
  "airport",
  "aisle",
  "alarm",
  "album",
  "alcohol",
  "alert",
  "alien",
  "all",
  "alley",
  "allow",
  "almost",
  "alone",
  "alpha",
  "already",
  "also",
  "alter",
  "always",
  "amateur",
  "amazing",
  "among",
  "amount",
  "amused",
  "analyst",
  "anchor",
  "ancient",
  "anger",
  "angle",
  "angry",
  "animal",
  "ankle",
  "announce",
  "annual",
  "another",
  "answer",
  "antenna",
  "antique",
  "anxiety",
  "any",
  "apart",
  "apology",
  "appear",
  "apple",
  "approve",
  "april",
  "arch",
  "arctic",
  "area",
  "arena",
  "argue",
  "arm",
  "armed",
  "armor",
  "army",
  "around",
  "arrange",
  "arrest",
  "arrive",
  "arrow",
  "art",
  "artefact",
  "artist",
  "artwork",
  "ask",
  "aspect",
  "assault",
  "asset",
  "assist",
  "assume",
  "asthma",
  "athlete",
  "atom",
  "attack",
  "attend",
  "attitude",
  "attract",
  "auction",
  "audit",
  "august",
  "aunt",
  "author",
  "auto",
  "autumn",
  "average",
  "avocado",
  "avoid",
  "awake",
  "aware",
  "away",
  "awesome",
  "awful",
  "awkward",
  "axis",
  "baby",
  "bachelor",
  "bacon",
  "badge",
  "bag",
  "balance",
  "balcony",
  "ball",
  "bamboo",
  "banana",
  "banner",
  "bar",
  "barely",
  "bargain",
  "barrel",
  "base",
  "basic",
  "basket",
  "battle",
  "beach",
  "bean",
  "beauty",
  "because",
  "become",
  "beef",
  "before",
  "begin",
  "behave",
  "behind",
  "believe",
  "below",
  "belt",
  "bench",
  "benefit",
  "best",
  "betray",
  "better",
  "between",
  "beyond",
  "bicycle",
  "bid",
  "bike",
  "bind",
  "biology",
  "bird",
  "birth",
  "bitter",
  "black",
  "blade",
  "blame",
  "blanket",
  "blast",
  "bleak",
  "bless",
  "blind",
  "blood",
  "blossom",
  "blouse",
  "blue",
  "blur",
  "blush",
  "board",
  "boat",
  "body",
  "boil",
  "bomb",
  "bone",
  "bonus",
  "book",
  "boost",
  "border",
  "boring",
  "borrow",
  "boss",
  "bottom",
  "bounce",
  "box",
  "boy",
  "bracket",
  "brain",
  "brand",
  "brass",
  "brave",
  "bread",
  "breeze",
  "brick",
  "bridge",
  "brief",
  "bright",
  "bring",
  "brisk",
  "broccoli",
  "broken",
  "bronze",
  "broom",
  "brother",
  "brown",
  "brush",
  "bubble",
  "buddy",
  "budget",
  "buffalo",
  "build",
  "bulb",
  "bulk",
  "bullet",
  "bundle",
  "bunker",
  "burden",
  "burger",
  "burst",
  "bus",
  "business",
  "busy",
  "butter",
  "buyer",
  "buzz",
  "cabbage",
  "cabin",
  "cable",
  "cactus",
  "cage",
  "cake",
  "call",
  "calm",
  "camera",
  "camp",
  "can",
  "canal",
  "cancel",
  "candy",
  "cannon",
  "canoe",
  "canvas",
  "canyon",
  "capable",
  "capital",
  "captain",
  "car",
  "carbon",
  "card",
  "cargo",
  "carpet",
  "carry",
  "cart",
  "case",
  "cash",
  "casino",
  "castle",
  "casual",
  "cat",
  "catalog",
  "catch",
  "category",
  "cattle",
  "caught",
  "cause",
  "caution",
  "cave",
  "ceiling",
  "celery",
  "cement",
  "census",
  "century",
  "cereal",
  "certain",
  "chair",
  "chalk",
  "champion",
  "change",
  "chaos",
  "chapter",
  "charge",
  "chase",
  "chat",
  "cheap",
  "check",
  "cheese",
  "chef",
  "cherry",
  "chest",
  "chicken",
  "chief",
  "child",
  "chimney",
  "choice",
  "choose",
  "chronic",
  "chuckle",
  "chunk",
  "churn",
  "cigar",
  "cinnamon",
  "circle",
  "citizen",
  "city",
  "civil",
  "claim",
  "clap",
  "clarify",
  "claw",
  "clay",
  "clean",
  "clerk",
  "clever",
  "click",
  "client",
  "cliff",
  "climb",
  "clinic",
  "clip",
  "clock",
  "clog",
  "close",
  "cloth",
  "cloud",
  "clown",
  "club",
  "clump",
  "cluster",
  "clutch",
  "coach",
  "coast",
  "coconut",
  "code",
  "coffee",
  "coil",
  "coin",
  "collect",
  "color",
  "column",
  "combine",
  "come",
  "comfort",
  "comic",
  "common",
  "company",
  "concert",
  "conduct",
  "confirm",
  "congress",
  "connect",
  "consider",
  "control",
  "convince",
  "cook",
  "cool",
  "copper",
  "copy",
  "coral",
  "core",
  "corn",
  "correct",
  "cost",
  "cotton",
  "couch",
  "country",
  "couple",
  "course",
  "cousin",
  "cover",
  "coyote",
  "crack",
  "cradle",
  "craft",
  "cram",
  "crane",
  "crash",
  "crater",
  "crawl",
  "crazy",
  "cream",
  "credit",
  "creek",
  "crew",
  "cricket",
  "crime",
  "crisp",
  "critic",
  "crop",
  "cross",
  "crouch",
  "crowd",
  "crucial",
  "cruel",
  "cruise",
  "crumble",
  "crunch",
  "crush",
  "cry",
  "crystal",
  "cube",
  "culture",
  "cup",
  "cupboard",
  "curious",
  "current",
  "curtain",
  "curve",
  "cushion",
  "custom",
  "cute",
  "cycle",
  "dad",
  "damage",
  "damp",
  "dance",
  "danger",
  "daring",
  "dash",
  "daughter",
  "dawn",
  "day",
  "deal",
  "debate",
  "debris",
  "decade",
  "december",
  "decide",
  "decline",
  "decorate",
  "decrease",
  "deer",
  "defense",
  "define",
  "defy",
  "degree",
  "delay",
  "deliver",
  "demand",
  "demise",
  "denial",
  "dentist",
  "deny",
  "depart",
  "depend",
  "deposit",
  "depth",
  "deputy",
  "derive",
  "describe",
  "desert",
  "design",
  "desk",
  "despair",
  "destroy",
  "detail",
  "detect",
  "develop",
  "device",
  "devote",
  "diagram",
  "dial",
  "diamond",
  "diary",
  "dice",
  "diesel",
  "diet",
  "differ",
  "digital",
  "dignity",
  "dilemma",
  "dinner",
  "dinosaur",
  "direct",
  "dirt",
  "disagree",
  "discover",
  "disease",
  "dish",
  "dismiss",
  "disorder",
  "display",
  "distance",
  "divert",
  "divide",
  "divorce",
  "dizzy",
  "doctor",
  "document",
  "dog",
  "doll",
  "dolphin",
  "domain",
  "donate",
  "donkey",
  "donor",
  "door",
  "dose",
  "double",
  "dove",
  "draft",
  "dragon",
  "drama",
  "drastic",
  "draw",
  "dream",
  "dress",
  "drift",
  "drill",
  "drink",
  "drip",
  "drive",
  "drop",
  "drum",
  "dry",
  "duck",
  "dumb",
  "dune",
  "during",
  "dust",
  "dutch",
  "duty",
  "dwarf",
  "dynamic",
  "eager",
  "eagle",
  "early",
  "earn",
  "earth",
  "easily",
  "east",
  "easy",
  "echo",
  "ecology",
  "economy",
  "edge",
  "edit",
  "educate",
  "effort",
  "egg",
  "eight",
  "either",
  "elbow",
  "elder",
  "electric",
  "elegant",
  "element",
  "elephant",
  "elevator",
  "elite",
  "else",
  "embark",
  "embody",
  "embrace",
  "emerge",
  "emotion",
  "employ",
  "empower",
  "empty",
  "enable",
  "enact",
  "end",
  "endless",
  "endorse",
  "enemy",
  "energy",
  "enforce",
  "engage",
  "engine",
  "enhance",
  "enjoy",
  "enlist",
  "enough",
  "enrich",
  "enroll",
  "ensure",
  "enter",
  "entire",
  "entry",
  "envelope",
  "episode",
  "equal",
  "equip",
  "era",
  "erase",
  "erode",
  "erosion",
  "error",
  "erupt",
  "escape",
  "essay",
  "essence",
  "estate",
  "eternal",
  "ethics",
  "evidence",
  "evil",
  "evoke",
  "evolve",
  "exact",
  "example",
  "excess",
  "exchange",
  "excite",
  "exclude",
  "excuse",
  "execute",
  "exercise",
  "exhaust",
  "exhibit",
  "exile",
  "exist",
  "exit",
  "exotic",
  "expand",
  "expect",
  "expire",
  "explain",
  "expose",
  "express",
  "extend",
  "extra",
  "eye",
  "eyebrow",
  "fabric",
  "face",
  "faculty",
  "fade",
  "faint",
  "faith",
  "fall",
  "false",
  "fame",
  "family",
  "famous",
  "fan",
  "fancy",
  "fantasy",
  "farm",
  "fashion",
  "fat",
  "fatal",
  "father",
  "fatigue",
  "fault",
  "favorite",
  "feature",
  "february",
  "federal",
  "fee",
  "feed",
  "feel",
  "female",
  "fence",
  "festival",
  "fetch",
  "fever",
  "few",
  "fiber",
  "fiction",
  "field",
  "figure",
  "file",
  "film",
  "filter",
  "final",
  "find",
  "fine",
  "finger",
  "finish",
  "fire",
  "firm",
  "first",
  "fiscal",
  "fish",
  "fit",
  "fitness",
  "fix",
  "flag",
  "flame",
  "flash",
  "flat",
  "flavor",
  "flee",
  "flight",
  "flip",
  "float",
  "flock",
  "floor",
  "flower",
  "fluid",
  "flush",
  "fly",
  "foam",
  "focus",
  "fog",
  "foil",
  "fold",
  "follow",
  "food",
  "foot",
  "force",
  "forest",
  "forget",
  "fork",
  "fortune",
  "forum",
  "forward",
  "fossil",
  "foster",
  "found",
  "fox",
  "fragile",
  "frame",
  "frequent",
  "fresh",
  "friend",
  "fringe",
  "frog",
  "front",
  "frost",
  "frown",
  "frozen",
  "fruit",
  "fuel",
  "fun",
  "funny",
  "furnace",
  "fury",
  "future",
  "gadget",
  "gain",
  "galaxy",
  "gallery",
  "game",
  "gap",
  "garage",
  "garbage",
  "garden",
  "garlic",
  "garment",
  "gas",
  "gasp",
  "gate",
  "gather",
  "gauge",
  "gaze",
  "general",
  "genius",
  "genre",
  "gentle",
  "genuine",
  "gesture",
  "ghost",
  "giant",
  "gift",
  "giggle",
  "ginger",
  "giraffe",
  "girl",
  "give",
  "glad",
  "glance",
  "glare",
  "glass",
  "glide",
  "glimpse",
  "globe",
  "gloom",
  "glory",
  "glove",
  "glow",
  "glue",
  "goat",
  "goddess",
  "gold",
  "good",
  "goose",
  "gorilla",
  "gospel",
  "gossip",
  "govern",
  "gown",
  "grab",
  "grace",
  "grain",
  "grant",
  "grape",
  "grass",
  "gravity",
  "great",
  "green",
  "grid",
  "grief",
  "grit",
  "grocery",
  "group",
  "grow",
  "grunt",
  "guard",
  "guess",
  "guide",
  "guilt",
  "guitar",
  "gun",
  "gym",
  "habit",
  "hair",
  "half",
  "hammer",
  "hamster",
  "hand",
  "happy",
  "harbor",
  "hard",
  "harsh",
  "harvest",
  "hat",
  "have",
  "hawk",
  "hazard",
  "head",
  "health",
  "heart",
  "heavy",
  "hedgehog",
  "height",
  "hello",
  "helmet",
  "help",
  "hen",
  "hero",
  "hidden",
  "high",
  "hill",
  "hint",
  "hip",
  "hire",
  "history",
  "hobby",
  "hockey",
  "hold",
  "hole",
  "holiday",
  "hollow",
  "home",
  "honey",
  "hood",
  "hope",
  "horn",
  "horror",
  "horse",
  "hospital",
  "host",
  "hotel",
  "hour",
  "hover",
  "hub",
  "huge",
  "human",
  "humble",
  "humor",
  "hundred",
  "hungry",
  "hunt",
  "hurdle",
  "hurry",
  "hurt",
  "husband",
  "hybrid",
  "ice",
  "icon",
  "idea",
  "identify",
  "idle",
  "ignore",
  "ill",
  "illegal",
  "illness",
  "image",
  "imitate",
  "immense",
  "immune",
  "impact",
  "impose",
  "improve",
  "impulse",
  "inch",
  "include",
  "income",
  "increase",
  "index",
  "indicate",
  "indoor",
  "industry",
  "infant",
  "inflict",
  "inform",
  "inhale",
  "inherit",
  "initial",
  "inject",
  "injury",
  "inmate",
  "inner",
  "innocent",
  "input",
  "inquiry",
  "insane",
  "insect",
  "inside",
  "inspire",
  "install",
  "intact",
  "interest",
  "into",
  "invest",
  "invite",
  "involve",
  "iron",
  "island",
  "isolate",
  "issue",
  "item",
  "ivory",
  "jacket",
  "jaguar",
  "jar",
  "jazz",
  "jealous",
  "jeans",
  "jelly",
  "jewel",
  "job",
  "join",
  "joke",
  "journey",
  "joy",
  "judge",
  "juice",
  "jump",
  "jungle",
  "junior",
  "junk",
  "just",
  "kangaroo",
  "keen",
  "keep",
  "ketchup",
  "key",
  "kick",
  "kid",
  "kidney",
  "kind",
  "kingdom",
  "kiss",
  "kit",
  "kitchen",
  "kite",
  "kitten",
  "kiwi",
  "knee",
  "knife",
  "knock",
  "know",
  "lab",
  "label",
  "labor",
  "ladder",
  "lady",
  "lake",
  "lamp",
  "language",
  "laptop",
  "large",
  "later",
  "latin",
  "laugh",
  "laundry",
  "lava",
  "law",
  "lawn",
  "lawsuit",
  "layer",
  "lazy",
  "leader",
  "leaf",
  "learn",
  "leave",
  "lecture",
  "left",
  "leg",
  "legal",
  "legend",
  "leisure",
  "lemon",
  "lend",
  "length",
  "lens",
  "leopard",
  "lesson",
  "letter",
  "level",
  "liar",
  "liberty",
  "library",
  "license",
  "life",
  "lift",
  "light",
  "like",
  "limb",
  "limit",
  "link",
  "lion",
  "liquid",
  "list",
  "little",
  "live",
  "lizard",
  "load",
  "loan",
  "lobster",
  "local",
  "lock",
  "logic",
  "lonely",
  "long",
  "loop",
  "lottery",
  "loud",
  "lounge",
  "love",
  "loyal",
  "lucky",
  "luggage",
  "lumber",
  "lunar",
  "lunch",
  "luxury",
  "lyrics",
  "machine",
  "mad",
  "magic",
  "magnet",
  "maid",
  "mail",
  "main",
  "major",
  "make",
  "mammal",
  "man",
  "manage",
  "mandate",
  "mango",
  "mansion",
  "manual",
  "maple",
  "marble",
  "march",
  "margin",
  "marine",
  "market",
  "marriage",
  "mask",
  "mass",
  "master",
  "match",
  "material",
  "math",
  "matrix",
  "matter",
  "maximum",
  "maze",
  "meadow",
  "mean",
  "measure",
  "meat",
  "mechanic",
  "medal",
  "media",
  "melody",
  "melt",
  "member",
  "memory",
  "mention",
  "menu",
  "mercy",
  "merge",
  "merit",
  "merry",
  "mesh",
  "message",
  "metal",
  "method",
  "middle",
  "midnight",
  "milk",
  "million",
  "mimic",
  "mind",
  "minimum",
  "minor",
  "minute",
  "miracle",
  "mirror",
  "misery",
  "miss",
  "mistake",
  "mix",
  "mixed",
  "mixture",
  "mobile",
  "model",
  "modify",
  "mom",
  "moment",
  "monitor",
  "monkey",
  "monster",
  "month",
  "moon",
  "moral",
  "more",
  "morning",
  "mosquito",
  "mother",
  "motion",
  "motor",
  "mountain",
  "mouse",
  "move",
  "movie",
  "much",
  "muffin",
  "mule",
  "multiply",
  "muscle",
  "museum",
  "mushroom",
  "music",
  "must",
  "mutual",
  "myself",
  "mystery",
  "myth",
  "naive",
  "name",
  "napkin",
  "narrow",
  "nasty",
  "nation",
  "nature",
  "near",
  "neck",
  "need",
  "negative",
  "neglect",
  "neither",
  "nephew",
  "nerve",
  "nest",
  "net",
  "network",
  "neutral",
  "never",
  "news",
  "next",
  "nice",
  "night",
  "noble",
  "noise",
  "nominee",
  "noodle",
  "normal",
  "north",
  "nose",
  "notable",
  "note",
  "nothing",
  "notice",
  "novel",
  "now",
  "nuclear",
  "number",
  "nurse",
  "nut",
  "oak",
  "obey",
  "object",
  "oblige",
  "obscure",
  "observe",
  "obtain",
  "obvious",
  "occur",
  "ocean",
  "october",
  "odor",
  "off",
  "offer",
  "office",
  "often",
  "oil",
  "okay",
  "old",
  "olive",
  "olympic",
  "omit",
  "once",
  "one",
  "onion",
  "online",
  "only",
  "open",
  "opera",
  "opinion",
  "oppose",
  "option",
  "orange",
  "orbit",
  "orchard",
  "order",
  "ordinary",
  "organ",
  "orient",
  "original",
  "orphan",
  "ostrich",
  "other",
  "outdoor",
  "outer",
  "output",
  "outside",
  "oval",
  "oven",
  "over",
  "own",
  "owner",
  "oxygen",
  "oyster",
  "ozone",
  "pact",
  "paddle",
  "page",
  "pair",
  "palace",
  "palm",
  "panda",
  "panel",
  "panic",
  "panther",
  "paper",
  "parade",
  "parent",
  "park",
  "parrot",
  "party",
  "pass",
  "patch",
  "path",
  "patient",
  "patrol",
  "pattern",
  "pause",
  "pave",
  "payment",
  "peace",
  "peanut",
  "pear",
  "peasant",
  "pelican",
  "pen",
  "penalty",
  "pencil",
  "people",
  "pepper",
  "perfect",
  "permit",
  "person",
  "pet",
  "phone",
  "photo",
  "phrase",
  "physical",
  "piano",
  "picnic",
  "picture",
  "piece",
  "pig",
  "pigeon",
  "pill",
  "pilot",
  "pink",
  "pioneer",
  "pipe",
  "pistol",
  "pitch",
  "pizza",
  "place",
  "planet",
  "plastic",
  "plate",
  "play",
  "please",
  "pledge",
  "pluck",
  "plug",
  "plunge",
  "poem",
  "poet",
  "point",
  "polar",
  "pole",
  "police",
  "pond",
  "pony",
  "pool",
  "popular",
  "portion",
  "position",
  "possible",
  "post",
  "potato",
  "pottery",
  "poverty",
  "powder",
  "power",
  "practice",
  "praise",
  "predict",
  "prefer",
  "prepare",
  "present",
  "pretty",
  "prevent",
  "price",
  "pride",
  "primary",
  "print",
  "priority",
  "prison",
  "private",
  "prize",
  "problem",
  "process",
  "produce",
  "profit",
  "program",
  "project",
  "promote",
  "proof",
  "property",
  "prosper",
  "protect",
  "proud",
  "provide",
  "public",
  "pudding",
  "pull",
  "pulp",
  "pulse",
  "pumpkin",
  "punch",
  "pupil",
  "puppy",
  "purchase",
  "purity",
  "purpose",
  "purse",
  "push",
  "put",
  "puzzle",
  "pyramid",
  "quality",
  "quantum",
  "quarter",
  "question",
  "quick",
  "quit",
  "quiz",
  "quote",
  "rabbit",
  "raccoon",
  "race",
  "rack",
  "radar",
  "radio",
  "rail",
  "rain",
  "raise",
  "rally",
  "ramp",
  "ranch",
  "random",
  "range",
  "rapid",
  "rare",
  "rate",
  "rather",
  "raven",
  "raw",
  "razor",
  "ready",
  "real",
  "reason",
  "rebel",
  "rebuild",
  "recall",
  "receive",
  "recipe",
  "record",
  "recycle",
  "reduce",
  "reflect",
  "reform",
  "refuse",
  "region",
  "regret",
  "regular",
  "reject",
  "relax",
  "release",
  "relief",
  "rely",
  "remain",
  "remember",
  "remind",
  "remove",
  "render",
  "renew",
  "rent",
  "reopen",
  "repair",
  "repeat",
  "replace",
  "report",
  "require",
  "rescue",
  "resemble",
  "resist",
  "resource",
  "response",
  "result",
  "retire",
  "retreat",
  "return",
  "reunion",
  "reveal",
  "review",
  "reward",
  "rhythm",
  "rib",
  "ribbon",
  "rice",
  "rich",
  "ride",
  "ridge",
  "rifle",
  "right",
  "rigid",
  "ring",
  "riot",
  "ripple",
  "risk",
  "ritual",
  "rival",
  "river",
  "road",
  "roast",
  "robot",
  "robust",
  "rocket",
  "romance",
  "roof",
  "rookie",
  "room",
  "rose",
  "rotate",
  "rough",
  "round",
  "route",
  "royal",
  "rubber",
  "rude",
  "rug",
  "rule",
  "run",
  "runway",
  "rural",
  "sad",
  "saddle",
  "sadness",
  "safe",
  "sail",
  "salad",
  "salmon",
  "salon",
  "salt",
  "salute",
  "same",
  "sample",
  "sand",
  "satisfy",
  "satoshi",
  "sauce",
  "sausage",
  "save",
  "say",
  "scale",
  "scan",
  "scare",
  "scatter",
  "scene",
  "scheme",
  "school",
  "science",
  "scissors",
  "scorpion",
  "scout",
  "scrap",
  "screen",
  "script",
  "scrub",
  "sea",
  "search",
  "season",
  "seat",
  "second",
  "secret",
  "section",
  "security",
  "seed",
  "seek",
  "segment",
  "select",
  "sell",
  "seminar",
  "senior",
  "sense",
  "sentence",
  "series",
  "service",
  "session",
  "settle",
  "setup",
  "seven",
  "shadow",
  "shaft",
  "shallow",
  "share",
  "shed",
  "shell",
  "sheriff",
  "shield",
  "shift",
  "shine",
  "ship",
  "shiver",
  "shock",
  "shoe",
  "shoot",
  "shop",
  "short",
  "shoulder",
  "shove",
  "shrimp",
  "shrug",
  "shuffle",
  "shy",
  "sibling",
  "sick",
  "side",
  "siege",
  "sight",
  "sign",
  "silent",
  "silk",
  "silly",
  "silver",
  "similar",
  "simple",
  "since",
  "sing",
  "siren",
  "sister",
  "situate",
  "six",
  "size",
  "skate",
  "sketch",
  "ski",
  "skill",
  "skin",
  "skirt",
  "skull",
  "slab",
  "slam",
  "sleep",
  "slender",
  "slice",
  "slide",
  "slight",
  "slim",
  "slogan",
  "slot",
  "slow",
  "slush",
  "small",
  "smart",
  "smile",
  "smoke",
  "smooth",
  "snack",
  "snake",
  "snap",
  "sniff",
  "snow",
  "soap",
  "soccer",
  "social",
  "sock",
  "soda",
  "soft",
  "solar",
  "soldier",
  "solid",
  "solution",
  "solve",
  "someone",
  "song",
  "soon",
  "sorry",
  "sort",
  "soul",
  "sound",
  "soup",
  "source",
  "south",
  "space",
  "spare",
  "spatial",
  "spawn",
  "speak",
  "special",
  "speed",
  "spell",
  "spend",
  "sphere",
  "spice",
  "spider",
  "spike",
  "spin",
  "spirit",
  "split",
  "spoil",
  "sponsor",
  "spoon",
  "sport",
  "spot",
  "spray",
  "spread",
  "spring",
  "spy",
  "square",
  "squeeze",
  "squirrel",
  "stable",
  "stadium",
  "staff",
  "stage",
  "stairs",
  "stamp",
  "stand",
  "start",
  "state",
  "stay",
  "steak",
  "steel",
  "stem",
  "step",
  "stereo",
  "stick",
  "still",
  "sting",
  "stock",
  "stomach",
  "stone",
  "stool",
  "story",
  "stove",
  "strategy",
  "street",
  "strike",
  "strong",
  "struggle",
  "student",
  "stuff",
  "stumble",
  "style",
  "subject",
  "submit",
  "subway",
  "success",
  "such",
  "sudden",
  "suffer",
  "sugar",
  "suggest",
  "suit",
  "summer",
  "sun",
  "sunny",
  "sunset",
  "super",
  "supply",
  "supreme",
  "sure",
  "surface",
  "surge",
  "surprise",
  "surround",
  "survey",
  "suspect",
  "sustain",
  "swallow",
  "swamp",
  "swap",
  "swarm",
  "swear",
  "sweet",
  "swift",
  "swim",
  "swing",
  "switch",
  "sword",
  "symbol",
  "symptom",
  "syrup",
  "system",
  "table",
  "tackle",
  "tag",
  "tail",
  "talent",
  "talk",
  "tank",
  "tape",
  "target",
  "task",
  "taste",
  "tattoo",
  "taxi",
  "teach",
  "team",
  "tell",
  "ten",
  "tenant",
  "tennis",
  "tent",
  "term",
  "test",
  "text",
  "thank",
  "that",
  "theme",
  "then",
  "theory",
  "there",
  "they",
  "thing",
  "this",
  "thought",
  "three",
  "thrive",
  "throw",
  "thumb",
  "thunder",
  "ticket",
  "tide",
  "tiger",
  "tilt",
  "timber",
  "time",
  "tiny",
  "tip",
  "tired",
  "tissue",
  "title",
  "toast",
  "tobacco",
  "today",
  "toddler",
  "toe",
  "together",
  "toilet",
  "token",
  "tomato",
  "tomorrow",
  "tone",
  "tongue",
  "tonight",
  "tool",
  "tooth",
  "top",
  "topic",
  "topple",
  "torch",
  "tornado",
  "tortoise",
  "toss",
  "total",
  "tourist",
  "toward",
  "tower",
  "town",
  "toy",
  "track",
  "trade",
  "traffic",
  "tragic",
  "train",
  "transfer",
  "trap",
  "trash",
  "travel",
  "tray",
  "treat",
  "tree",
  "trend",
  "trial",
  "tribe",
  "trick",
  "trigger",
  "trim",
  "trip",
  "trophy",
  "trouble",
  "truck",
  "true",
  "truly",
  "trumpet",
  "trust",
  "truth",
  "try",
  "tube",
  "tuition",
  "tumble",
  "tuna",
  "tunnel",
  "turkey",
  "turn",
  "turtle",
  "twelve",
  "twenty",
  "twice",
  "twin",
  "twist",
  "two",
  "type",
  "typical",
  "ugly",
  "umbrella",
  "unable",
  "unaware",
  "uncle",
  "uncover",
  "under",
  "undo",
  "unfair",
  "unfold",
  "unhappy",
  "uniform",
  "unique",
  "unit",
  "universe",
  "unknown",
  "unlock",
  "until",
  "unusual",
  "unveil",
  "update",
  "upgrade",
  "uphold",
  "upon",
  "upper",
  "upset",
  "urban",
  "urge",
  "usage",
  "use",
  "used",
  "useful",
  "useless",
  "usual",
  "utility",
  "vacant",
  "vacuum",
  "vague",
  "valid",
  "valley",
  "valve",
  "van",
  "vanish",
  "vapor",
  "various",
  "vast",
  "vault",
  "vehicle",
  "velvet",
  "vendor",
  "venture",
  "venue",
  "verb",
  "verify",
  "version",
  "very",
  "vessel",
  "veteran",
  "viable",
  "vibrant",
  "vicious",
  "victory",
  "video",
  "view",
  "village",
  "vintage",
  "violin",
  "virtual",
  "virus",
  "visa",
  "visit",
  "visual",
  "vital",
  "vivid",
  "vocal",
  "voice",
  "void",
  "volcano",
  "volume",
  "vote",
  "voyage",
  "wage",
  "wagon",
  "wait",
  "walk",
  "wall",
  "walnut",
  "want",
  "warfare",
  "warm",
  "warrior",
  "wash",
  "wasp",
  "waste",
  "water",
  "wave",
  "way",
  "wealth",
  "weapon",
  "wear",
  "weasel",
  "weather",
  "web",
  "wedding",
  "weekend",
  "weird",
  "welcome",
  "west",
  "wet",
  "whale",
  "what",
  "wheat",
  "wheel",
  "when",
  "where",
  "whip",
  "whisper",
  "wide",
  "width",
  "wife",
  "wild",
  "will",
  "win",
  "window",
  "wine",
  "wing",
  "wink",
  "winner",
  "winter",
  "wire",
  "wisdom",
  "wise",
  "wish",
  "witness",
  "wolf",
  "woman",
  "wonder",
  "wood",
  "wool",
  "word",
  "work",
  "world",
  "worry",
  "worth",
  "wrap",
  "wreck",
  "wrestle",
  "wrist",
  "write",
  "wrong",
  "yard",
  "year",
  "yellow",
  "you",
  "young",
  "youth",
  "zebra",
  "zero",
  "zone",
  "zoo"
];

let messageIdx = 0;
const TOM_PRIVATE_KEY = '041702f26adfb5d983a9fd36ada83367c64bd33b5f076b1e617c7e2158525735';
const TOM_PUBLIC_KEY = '04423dcbe8aea31971125bd18b26d5e5f257ffafffc7bb7f952d84f2ab908b587b5477ad49c9c37b2849a12d6c4f3570c3536ec5d5daccccb4e455f4de41bdc9d0';
const MIRZA_PRIVATE_KEY = '7477230f772b105d8aa028d56ca5b5d0f24838fb11f461000b512da4cfc8d38e';
const MIRZA_PUBLIC_KEY = '04afaefda0891eaeb6fd140c00c34f21f345f87160bb3509bfb0ef2b068dc9c9e7ff4233e2b16da297f7e4d4f0e2db5a6c49f88d73be3be7d8c5e31099f1927db7';

let myPrivKey = '';
let myPubKey = '';

function convertEncrypted(encrypted) {
  encrypted.iv = encrypted.iv.toString('hex');
  encrypted.ephemPublicKey = encrypted.ephemPublicKey.toString('hex');
  encrypted.ciphertext = encrypted.ciphertext.toString('hex');
  encrypted.mac = encrypted.mac.toString('hex');
  return encrypted;
}

function decodeMessage(fullMessage) {
  // find the message in [] messages that corresponds to your public address
  // decode the message with decodeJwt()
  // convert signature to Buffer values
  // verify that signature is correct (eccrypto.verify(from, SHA256(msg), signature))
  // if signature is correct, decrypt message with private key (eccrypto.decrypt), this returns a JWT
  // decode decrypted JWT - this is the message to display
}

function sha256(str) {
  // We transform the string into an arraybuffer.
  var buffer = new TextEncoder("utf-8").encode(str);
  return crypto.subtle.digest("SHA-256", buffer).then(function (hash) {
    return hex(hash);
  });
}

function hex(buffer) {
  var hexCodes = [];
  var view = new DataView(buffer);
  for (var i = 0; i < view.byteLength; i += 4) {
    // Using getUint32 reduces the number of iterations needed (we process 4 bytes each time)
    var value = view.getUint32(i)
    // toString(16) will give the hex representation of the number without padding
    var stringValue = value.toString(16)
    // We use concatenation and slice for padding
    var padding = '00000000'
    var paddedValue = (padding + stringValue).slice(-padding.length)
    hexCodes.push(paddedValue);
  }

  // Join all the hex strings into one
  return hexCodes.join("");
}

function getPrivateKeyFromPassphrase(passphrase) {

  let words = passphrase.split(' ');
  let privateKeyParts = [ ];
  for (let i = 0; i < words.length; i++) {
    let index = WORDS.indexOf(words[i]);
    // convert to base 2
    let base2Index = parseInt(index, 10).toString(2);

    while (base2Index.length < 11) {
      base2Index = '0' + base2Index;
    }
    privateKeyParts.push(base2Index);
  }
  let privateKey = parseInt(privateKeyParts.join('').substring(0, 256), 2).toString(16);
  let publicKey = eccrypto.getPublic(Buffer.from(privateKey, 'hex')).toString('hex');
  console.log('> Private/public key pair generated from passphrase: ', privateKey, publicKey);
  return { privateKey, publicKey };
}

function createToken(payload, key = 'abc') {
  const header = { typ: 'JWT', alg: 'HS256' };
  let encodedHeader = btoa(JSON.stringify(header));
  let stringifiedPayload = JSON.stringify(payload);
  let encodedPayload = btoa(stringifiedPayload).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');


  let segments = [ ];
  segments.push(encodedHeader);
  segments.push(encodedPayload);

  let unsignedToken = encodedHeader + '.' + encodedPayload;

  let signature = jwtSign(segments.join('.'), key);
  segments.push(signature);

  return segments.join('.');
}

function decodeJwt(token) {
  let base64Url = token.split('.')[1];
  let base64 = base64Url.replace('-', '+').replace('_', '/');
  return JSON.parse(atob(base64));
}

function jwtSign(data, key = 'abc') {
  crypto.subtle.importKey('jwk', { kty: 'oct', k: key, alg: 'HS256', ext: true }, { name: 'HMAC', hash: { name: 'SHA-256' } }, true, [ 'sign', 'verify' ])
  .then(key => {
    let jsonString = JSON.stringify(data);
    let encodedData = new TextEncoder().encode(jsonString);

    return crypto.subtle.sign({ name: 'HMAC' }, key, encodedData);
  })
  .then(token => {
    let u8 = new Uint8Array(token);
    let b64encoded = btoa(String.fromCharCode.apply(null, u8));
    console.log('> Token: ', b64encoded);
    return b64encoded;
  });
}

function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

function onError(event) {
  console.log('> Cancel onboarding: ', event);
  event.modalView.close();
}

var state = {
	loggedIn: false,
	passphrase: null,
	publicKey: null,
	privateKey: null,
	loaded: false,
	email: null,
  hasAccount: false,
};

Promise.all([
	InboxSDK.load(2, 'sdk_Mail3_0_bd399d860c'),
	InboxSDK.loadScript('https://s3.us-east-2.amazonaws.com/mailthreezero/eccrypto.min.js'),
	InboxSDK.loadScript('https://s3.us-east-2.amazonaws.com/mailthreezero/buffer.min.js'),
])
.then(function(results){
  console.log('> Finished loading crypto script...', window.eccrypto);

  var sdk = results[0];

  // check if logged in or has account
  // check Cookie for private key and derive public key
  let privateKey = getCookie("PRIVATE_KEY");
  console.log('> Private key cookie: ', privateKey);
  let publicKey;
  if (privateKey && privateKey.length === 64) {
    publicKey = eccrypto.getPublic(Buffer.from(privateKey, 'hex')).toString('hex');
  }

  // get user email
  let email = sdk.User.getEmailAddress();
  let passphrase = '';
  console.log('> User email: ', email);
  // check if user email is registered with public key
  fetch(`https://api.mailthreezero.com/publicKey/${email.toLowerCase()}`, { headers }).then(res => {
    console.log('> Res: ', res);
    if (res.status === 200) {
      res.json().then(data => {
        console.log('> Email/public key: ', data);
        if (publicKey === data.publicKey) {
          myPubKey = data.publicKey;
          myPrivKey = data.privateKey;
          state.loggedIn = true;
        } else {
          // reset cookie to not logged in
          document.cookie = 'PRIVATE_KEY=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        }
      })
    } else {
      console.log('> Email fetch error: ', res.status);
      // reset cookie to not logged in
      document.cookie = 'PRIVATE_KEY=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      initOnboarding(onError);
    }
  })

  // check if user has account yet
  function initOnboarding(onError) {
    // generate random 12 words, convert to private key -> public key
    // save public key to API
    var modalOptions = {
			el: `
        <div class="Mail30-container"><style>*{box-sizing:border-box;font-family:'Helvetica Neue'}.Mail30-container{height:100%;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.Mail30-flex{display:flex;justify-content:center;align-items:center}.Mail30-bottom{width:50vw;flex-direction:column;padding:10px}.Mail30-modal-container{padding:0;margin:0;height:65vh}.Mail30-top-section{background:#212121;height:30%;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:15px;width:50vw;min-width:400px}.Mail30-banner{height:20%;min-height:100px}.Mail30-group{position:relative;margin-bottom:45px}input.Mail30-input{font-size:18px;padding:10px 10px 10px 5px;display:block;width:500px;border:0;border-bottom:1px solid #757575}input.Mail30-input:focus{outline:0}label.Mail30-label{color:#999;font-size:18px;font-weight:normal;position:absolute;pointer-events:none;left:5px;top:10px;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}input.Mail30-input:focus~label,input.Mail30-input:valid~label{top:-20px;font-size:14px;color:#5264ae}.Mail30-bar{position:relative;display:block;width:500px}.Mail30-bar:before,.Mail30-bar:after{content:'';height:2px;width:0;bottom:1px;position:absolute;background:#5264ae;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}.Mail30-bar:before{left:50%}.Mail30-bar:after{right:50%}input.Mail30-input:focus~.Mail30-bar:before,input.Mail30-input:focus~.Mail30-bar:after{width:50%}.Mail30-highlight{position:absolute;height:60%;width:100px;top:25%;left:0;pointer-events:none;opacity:.5}input.Mail30-input:focus~.Mail30-highlight{-webkit-animation:inputHighlighter .3s ease;-moz-animation:inputHighlighter .3s ease;animation:inputHighlighter .3s ease}@-webkit-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@-moz-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}.Mail30-btn{position:relative;display:block;margin:15px 5px;padding:0;overflow:hidden;border-width:0;outline:0;border-radius:2px;box-shadow:0 1px 4px rgba(0,0,0,.6);background-color:#4285f4;color:#ecf0f1;transition:background-color .3s}.Mail30-btn:hover,.Mail30-btn:focus{background-color:#2d5ac8}.Mail30-btn>*{position:relative}.Mail30-btn span{display:block;padding:12px 24px;font-family:'Helvetica Neue'}.Mail30-h1{margin:0;padding:20px;color:#212121;font-size:40;font-family:Helvetica Neue;font-weight:semi-bold;text-align:center;justify-content:center}.Mail30-btn:before{content:"";position:absolute;top:50%;left:50%;display:block;width:0;padding-top:0;border-radius:100%;background-color:rgba(236,240,241,.3);-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.Mail30-btn:active:before{width:120%;padding-top:120%;transition:width .2s ease-out,padding-top .2s ease-out}.Mail30-btn.gray{background-color:#f2f2f2;color:black}.Mail30-btn.gray:hover,.Mail30-btn.gray:focus{background-color:#e6e6e6}.Mail30-p{color:#424242;font-size:18px;text-align:center}</style><div class="Mail30-modal-container"><section class="Mail30-top-section" style="height:45%;min-height:200px"><img alt="mail 3.0 logo" src="https://s3.us-east-2.amazonaws.com/mailthreezero/Logo+2.png" class="Mail30-banner" /><h1 style="color:#CAC4C9;font-size:28px;font-weight:300" class="Mail30-h1">Decentralized mail,made easy</h1></section><section class="Mail30-bottom Mail30-flex"><h1 class="Mail30-h1">Welcome to Mail 3.0!</h1><div class="Mail30-group" style="margin:15px"><p class="Mail30-p">To get started,click &quot;NEXT&quot;to generate a passphrase to encrypt your emails.</p></div></section><section class="Mail30-buttons Mail30-flex"><div></div><div class="Mail30-flex"><button class="Mail30-btn gray" id="Mail30-cancel" type="button"><span>CANCEL</span></button><button class="Mail30-btn" id="Mail30-submit" type="button"><span>NEXT</span></button></div></section></div></div>
      `,
			chrome: false,
		};
		var modalView = sdk.Widgets.showModalView(modalOptions);
    console.log('> Modal view: ', modalView);

    document.getElementById('Mail30-cancel').onclick = function() {
      console.log('> Cancel: ');
			onError({ modalView });
    }
    document.getElementById('Mail30-submit').onclick = function() {
      console.log('> Submit: ', event); // go to next screen
      // generate random passphrase
      var privateKey = crypto.getRandomValues(new Uint8Array(32));
      privateKey = Array.prototype.map.call(new Uint8Array(privateKey.buffer), x => {
        let digits = x.toString(2);
        while (digits.length < 8) {
          digits = '0' + digits;
        }
        return digits;
      }).join('');
      let passphraseParts = [ ];
      // pad private key with zeros
      let privateKeyHex = parseInt(privateKey, 2).toString(16);
      // determine public key
      // store private key locally
      let publicKey = eccrypto.getPublic(Buffer.from(privateKeyHex, 'hex')).toString('hex');
      console.log('> Public/Private key pair: ', privateKeyHex, publicKey);
      sha256(privateKeyHex).then(digest => {
        var checksum = parseInt(digest, 16).toString(2).substring(0, 8);
        var extendedPrivateKey = privateKey + checksum; // 132 bits
        // break into groups of 11
        let words = new Array(24).map(x => 0);
        for (let i = 0; i < words.length; i++) {
          let substr = extendedPrivateKey.substring(i * 11, (i * 11) + 11);
          let word = WORDS[parseInt(substr, 2)];
          passphraseParts.push(word);
        }
        passphrase = passphraseParts.join(' ');
        let checkPrivateKey = getPrivateKeyFromPassphrase(passphrase);
        console.log('> Check private key pair: ', checkPrivateKey, privateKeyHex, publicKey);
        // save private key locally
        document.cookie = "PRIVATE_KEY=" + privateKeyHex;
        myPrivKey = privateKeyHex;
        myPubKey = publicKey;

        // save public key + email to database
        fetch('https://api.mailthreezero.com/publicKeys', { method: 'POST', headers, body: JSON.stringify({ email: email, publicKey: publicKey }) }).then(res => {
          if (res.status === 200) {
            res.json().then(data => console.log('> Email / public key pair saved :', email, publicKey));
            state.loggedIn = true;
            initAccount(onError);
            modalView.close();
          } else {
            // show error
            showError('Error connecting to Mail 3.0');
          }
        })
      });
    }
  }

  function initAccount(onError) {
    var modalOptions = {
			el: `
        <div class="Mail30-container"><style>*{box-sizing:border-box;font-family:'Helvetica Neue'}.Mail30-container{height:100%;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.Mail30-flex{display:flex;justify-content:center;align-items:center}.Mail30-bottom{width:50vw;flex-direction:column;padding:10px}.Mail30-modal-container{padding:0;margin:0;height:65vh}.Mail30-top-section{background:#212121;height:30%;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:15px;width:50vw;min-width:400px}.Mail30-banner{height:20%;min-height:100px}.Mail30-group{position:relative;margin-bottom:45px}input.Mail30-input{font-size:18px;padding:10px 10px 10px 5px;display:block;width:500px;border:0;border-bottom:1px solid #757575}input.Mail30-input:focus{outline:0}label.Mail30-label{color:#999;font-size:18px;font-weight:normal;position:absolute;pointer-events:none;left:5px;top:10px;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}input.Mail30-input:focus~label,input.Mail30-input:valid~label{top:-20px;font-size:14px;color:#5264ae}.Mail30-bar{position:relative;display:block;width:500px}.Mail30-bar:before,.Mail30-bar:after{content:'';height:2px;width:0;bottom:1px;position:absolute;background:#5264ae;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}.Mail30-bar:before{left:50%}.Mail30-bar:after{right:50%}input.Mail30-input:focus~.Mail30-bar:before,input.Mail30-input:focus~.Mail30-bar:after{width:50%}.Mail30-highlight{position:absolute;height:60%;width:100px;top:25%;left:0;pointer-events:none;opacity:.5}input.Mail30-input:focus~.Mail30-highlight{-webkit-animation:inputHighlighter .3s ease;-moz-animation:inputHighlighter .3s ease;animation:inputHighlighter .3s ease}@-webkit-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@-moz-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}.Mail30-btn{position:relative;display:block;margin:15px 5px;padding:0;overflow:hidden;border-width:0;outline:0;border-radius:2px;box-shadow:0 1px 4px rgba(0,0,0,.6);background-color:#4285f4;color:#ecf0f1;transition:background-color .3s}.Mail30-btn:hover,.Mail30-btn:focus{background-color:#2d5ac8}.Mail30-btn>*{position:relative}.Mail30-btn span{display:block;padding:12px 24px;font-family:'Helvetica Neue'}.Mail30-h1{margin:0;padding:20px;color:#212121;font-size:40;font-family:Helvetica Neue;font-weight:semi-bold;text-align:center;justify-content:center}.Mail30-btn:before{content:"";position:absolute;top:50%;left:50%;display:block;width:0;padding-top:0;border-radius:100%;background-color:rgba(236,240,241,.3);-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.Mail30-btn:active:before{width:120%;padding-top:120%;transition:width .2s ease-out,padding-top .2s ease-out}.Mail30-btn.gray{background-color:#f2f2f2;color:black}.Mail30-btn.gray:hover,.Mail30-btn.gray:focus{background-color:#e6e6e6}.Mail30-p{color:#424242;font-size:18px;text-align:center}</style><div class="Mail30-modal-container"><section class="Mail30-top-section" style="height:45%;min-height:200px;background:#F2F2F2"><h1 class="Mail30-h1">Your Passphrase</h1><div style="background:#FFF;width:90%;text-align:center"><h1>${passphrase}</h1></div></section><section class="Mail30-bottom Mail30-flex"><div class="Mail30-group" style="margin:15px"><p class="Mail30-p">We recommend that you write down the passphrase and store it somewhere secure. You can also use a password manager such as LastPass or 1Password to manage your passphrase.</p></div></section><section class="Mail30-buttons Mail30-flex"><div></div><div class="Mail30-flex"><button class="Mail30-btn gray" id="Mail30-cancel" type="button"><span>CANCEL</span></button><button class="Mail30-btn" id="Mail30-submit" type="button"><span>NEXT</span></button></div></section></div></div>
      `,
			chrome: false,
		};
		var modalView = sdk.Widgets.showModalView(modalOptions);
    console.log('> Modal view: ', modalView);

    document.getElementById('Mail30-cancel').onclick = function() {
      console.log('> Cancel: ');
			onError({ modalView });
    }
    document.getElementById('Mail30-submit').onclick = function() {
      console.log('> Submit: ', event); // go to next screen
      // save passphrase -> private key -> public key
      // save public key + email to API and log in
      // set cookie of private key
      // show feature page
      showFeatures(onError);
      modalView.close();
    }
    // get checksum of SHA256

    // add to entropy and divide into 11-bit sections
    // map each 11-bit value to a word
    // mnemonic is sequence of words
    // convert into private key -> public key
    // save public key with email in API / db
    // display new modal with generated passphrase and instructions
  }

  function showFeatures(onError) {
    // show features screen, pt #1
    var modalOptions = {
			el: `
        <div class="Mail30-container"><style>*{box-sizing:border-box;font-family:'Helvetica Neue'}.Mail30-container{height:100%;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.Mail30-flex{display:flex;justify-content:center;align-items:center}.Mail30-flex-1{flex:1}.Mail30-bottom{width:50vw;flex-direction:column;padding:10px}.Mail30-modal-container{padding:0;margin:0;height:65vh}.Mail30-top-section{background:#212121;height:30%;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:15px;width:50vw;min-width:400px}.Mail30-banner{height:20%;min-height:100px}.Mail30-feature{height:150px}.Mail30-group{position:relative;margin-bottom:45px}input.Mail30-input{font-size:18px;padding:10px 10px 10px 5px;display:block;width:500px;border:0;border-bottom:1px solid #757575}input.Mail30-input:focus{outline:0}label.Mail30-label{color:#999;font-size:18px;font-weight:normal;position:absolute;pointer-events:none;left:5px;top:10px;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}input.Mail30-input:focus~label,input.Mail30-input:valid~label{top:-20px;font-size:14px;color:#5264ae}.Mail30-bar{position:relative;display:block;width:500px}.Mail30-bar:before,.Mail30-bar:after{content:'';height:2px;width:0;bottom:1px;position:absolute;background:#5264ae;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}.Mail30-bar:before{left:50%}.Mail30-bar:after{right:50%}input.Mail30-input:focus~.Mail30-bar:before,input.Mail30-input:focus~.Mail30-bar:after{width:50%}.Mail30-highlight{position:absolute;height:60%;width:100px;top:25%;left:0;pointer-events:none;opacity:.5}input.Mail30-input:focus~.Mail30-highlight{-webkit-animation:inputHighlighter .3s ease;-moz-animation:inputHighlighter .3s ease;animation:inputHighlighter .3s ease}@-webkit-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@-moz-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}.Mail30-btn{position:relative;display:block;margin:15px 5px;padding:0;overflow:hidden;border-width:0;outline:0;border-radius:2px;box-shadow:0 1px 4px rgba(0,0,0,.6);background-color:#4285f4;color:#ecf0f1;transition:background-color .3s}.Mail30-btn:hover,.Mail30-btn:focus{background-color:#2d5ac8}.Mail30-btn>*{position:relative}.Mail30-btn span{display:block;padding:12px 24px;font-family:'Helvetica Neue'}.Mail30-h1{margin:0;padding:20px;color:#212121;font-size:40;font-family:Helvetica Neue;font-weight:semi-bold;text-align:center;justify-content:center}.Mail30-btn:before{content:"";position:absolute;top:50%;left:50%;display:block;width:0;padding-top:0;border-radius:100%;background-color:rgba(236,240,241,.3);-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.Mail30-btn:active:before{width:120%;padding-top:120%;transition:width .2s ease-out,padding-top .2s ease-out}.Mail30-btn.gray{background-color:#f2f2f2;color:black}.Mail30-btn.gray:hover,.Mail30-btn.gray:focus{background-color:#e6e6e6}.Mail30-p{color:#424242;font-size:18px;text-align:center}</style><div class="Mail30-modal-container"><section class="Mail30-top-section flex" style="height:45%;min-height:200px;flex-direction:row"><div class="Mail30-flex-1 Mail30-flex"><h1 style="color:#CAC4C9;font-size:28px;font-weight:300" class="Mail30-h1">Secure Messaging</h1></div><div class="Mail30-flex-1 Mail30-flex"><img alt="mail 3.0 logo" src="https://s3.us-east-2.amazonaws.com/mailthreezero/Features_02.png" class="Mail30-feature" /></div></section><section class="Mail30-bottom Mail30-flex"><div class="Mail30-group" style="margin:15px"><p class="Mail30-p">When you compose a message,press the Mail 3 icon to encrypt the contents and send it to the blockchain.</p></div></section><section class="Mail30-buttons Mail30-flex"><div></div><div class="Mail30-flex"><button class="Mail30-btn gray" id="Mail30-cancel" type="button"><span>SKIP</span></button><button class="Mail30-btn" id="Mail30-submit" type="button"><span>NEXT</span></button></div></section></div></div>
      `,
			chrome: false,
		};
		var modalView = sdk.Widgets.showModalView(modalOptions);
    console.log('> Modal view: ', modalView);

    document.getElementById('Mail30-cancel').onclick = function() {
      console.log('> Cancel: ');
			onError({ modalView });
    }
    document.getElementById('Mail30-submit').onclick = function() {
      console.log('> Next features page: ', event); // go to next screen
      showMoreFeatures(onError);
      modalView.close();
    }
  }

  function showMoreFeatures(onError) {
    // show last features screen (pt #2)
    // show features screen, pt #1
    var modalOptions = {
			el: `
        <div class="Mail30-container"><style>*{box-sizing:border-box;font-family:'Helvetica Neue'}.Mail30-container{height:100%;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.Mail30-flex{display:flex;justify-content:center;align-items:center}.Mail30-flex-1{flex:1}.Mail30-bottom{width:50vw;flex-direction:column;padding:10px}.Mail30-modal-container{padding:0;margin:0;height:65vh}.Mail30-top-section{background:#212121;height:30%;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:15px;width:50vw;min-width:400px}.Mail30-banner{height:20%;min-height:100px}.Mail30-feature{height:150px}.Mail30-group{position:relative;margin-bottom:45px}input.Mail30-input{font-size:18px;padding:10px 10px 10px 5px;display:block;width:500px;border:0;border-bottom:1px solid #757575}input.Mail30-input:focus{outline:0}label.Mail30-label{color:#999;font-size:18px;font-weight:normal;position:absolute;pointer-events:none;left:5px;top:10px;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}input.Mail30-input:focus~label,input.Mail30-input:valid~label{top:-20px;font-size:14px;color:#5264ae}.Mail30-bar{position:relative;display:block;width:500px}.Mail30-bar:before,.Mail30-bar:after{content:'';height:2px;width:0;bottom:1px;position:absolute;background:#5264ae;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}.Mail30-bar:before{left:50%}.Mail30-bar:after{right:50%}input.Mail30-input:focus~.Mail30-bar:before,input.Mail30-input:focus~.Mail30-bar:after{width:50%}.Mail30-highlight{position:absolute;height:60%;width:100px;top:25%;left:0;pointer-events:none;opacity:.5}input.Mail30-input:focus~.Mail30-highlight{-webkit-animation:inputHighlighter .3s ease;-moz-animation:inputHighlighter .3s ease;animation:inputHighlighter .3s ease}@-webkit-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@-moz-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}.Mail30-btn{position:relative;display:block;margin:15px 5px;padding:0;overflow:hidden;border-width:0;outline:0;border-radius:2px;box-shadow:0 1px 4px rgba(0,0,0,.6);background-color:#4285f4;color:#ecf0f1;transition:background-color .3s}.Mail30-btn:hover,.Mail30-btn:focus{background-color:#2d5ac8}.Mail30-btn>*{position:relative}.Mail30-btn span{display:block;padding:12px 24px;font-family:'Helvetica Neue'}.Mail30-h1{margin:0;padding:20px;color:#212121;font-size:40;font-family:Helvetica Neue;font-weight:semi-bold;text-align:center;justify-content:center}.Mail30-btn:before{content:"";position:absolute;top:50%;left:50%;display:block;width:0;padding-top:0;border-radius:100%;background-color:rgba(236,240,241,.3);-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.Mail30-btn:active:before{width:120%;padding-top:120%;transition:width .2s ease-out,padding-top .2s ease-out}.Mail30-btn.gray{background-color:#f2f2f2;color:black}.Mail30-btn.gray:hover,.Mail30-btn.gray:focus{background-color:#e6e6e6}.Mail30-p{color:#424242;font-size:18px;text-align:center}</style><div class="Mail30-modal-container"><section class="Mail30-top-section flex" style="height:45%;min-height:200px;flex-direction:row"><div class="Mail30-flex-1 Mail30-flex"><h1 style="color:#CAC4C9;font-size:28px;font-weight:300" class="Mail30-h1">Easy to Use</h1></div><div class="Mail30-flex-1 Mail30-flex"><img alt="mail 3.0 logo" src="https://s3.us-east-2.amazonaws.com/mailthreezero/Features_01.png" class="Mail30-feature" /></div></section><section class="Mail30-bottom Mail30-flex"><div class="Mail30-group" style="margin:15px"><p class="Mail30-p">Mail 3 automatically detects encrypted mail and decrypts it for you. Get more info by clicking the toolbar icon.</p></div></section><section class="Mail30-buttons Mail30-flex"><div></div><div class="Mail30-flex"><button class="Mail30-btn" id="Mail30-submit" type="button"><span>DONE</span></button></div></section></div></div>
      `,
			chrome: false,
		};
		var modalView = sdk.Widgets.showModalView(modalOptions);
    console.log('> Modal view: ', modalView);

    document.getElementById('Mail30-submit').onclick = function() {
      console.log('> Next features page: ', event); // go to next screen
      onError({ modalView });
      modalView.close();
    }
  }

  function showError(message) {
    sdk.ButterBar.showError({
      text: message,
      time: 5000,
      messageKey: ++messageIdx
    });
  }

  function showSuccess(message) {
    sdk.ButterBar.showMessage({
      text: message,
      time: 2000,
      messageKey: ++messageIdx
    });
  }

  function onSuccess(event) {
    console.log('> On success: ', event);
    // set as logged in
    state.loggedIn = true;
    // close modal
    event.modalView.close();
    // show success message
    showSuccess('Successfully logged in');
  }

  // the rest of your app code here
	function askUserToSignIn(onError, onSuccess) {
		var modalOptions = {
			el: `
        <div class="Mail30-container"><style>*{box-sizing:border-box;font-family:'Helvetica Neue'}.Mail30-container{height:100%;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center}.Mail30-flex{display:flex;justify-content:center;align-items:center}.Mail30-bottom{width:50vw;flex-direction:column;padding:10px}.Mail30-modal-container{padding:0;margin:0;height:65vh}.Mail30-top-section{background:#212121;height:30%;display:flex;flex-direction:column;justify-content:center;align-items:center;padding:15px;width:50vw;min-width:400px}.Mail30-banner{height:20%;min-height:100px}.Mail30-group{position:relative;margin-bottom:45px}input.Mail30-input{font-size:18px;padding:10px 10px 10px 5px;display:block;width:500px;border:0;border-bottom:1px solid #757575}input.Mail30-input:focus{outline:0}label.Mail30-label{color:#999;font-size:18px;font-weight:normal;position:absolute;pointer-events:none;left:5px;top:10px;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}input.Mail30-input:focus~label,input.Mail30-input:valid~label{top:-20px;font-size:14px;color:#5264ae}.Mail30-bar{position:relative;display:block;width:500px}.Mail30-bar:before,.Mail30-bar:after{content:'';height:2px;width:0;bottom:1px;position:absolute;background:#5264ae;transition:.2s ease all;-moz-transition:.2s ease all;-webkit-transition:.2s ease all}.Mail30-bar:before{left:50%}.Mail30-bar:after{right:50%}input.Mail30-input:focus~.Mail30-bar:before,input.Mail30-input:focus~.Mail30-bar:after{width:50%}.Mail30-highlight{position:absolute;height:60%;width:100px;top:25%;left:0;pointer-events:none;opacity:.5}input.Mail30-input:focus~.Mail30-highlight{-webkit-animation:inputHighlighter .3s ease;-moz-animation:inputHighlighter .3s ease;animation:inputHighlighter .3s ease}@-webkit-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@-moz-keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}@keyframes inputHighlighter{from{background:#5264ae}to{width:0;background:transparent}}.Mail30-btn{position:relative;display:block;margin:15px 5px;padding:0;overflow:hidden;border-width:0;outline:0;border-radius:2px;box-shadow:0 1px 4px rgba(0,0,0,.6);background-color:#4285f4;color:#ecf0f1;transition:background-color .3s}.Mail30-btn:hover,.Mail30-btn:focus{background-color:#2d5ac8}.Mail30-btn>*{position:relative}.Mail30-btn span{display:block;padding:12px 24px;font-family:'Helvetica Neue'}.Mail30-h1{margin:0;padding:20px;color:#212121;font-size:40;font-family:Helvetica Neue;font-weight:semi-bold;text-align:center;justify-content:center}.Mail30-btn:before{content:"";position:absolute;top:50%;left:50%;display:block;width:0;padding-top:0;border-radius:100%;background-color:rgba(236,240,241,.3);-webkit-transform:translate(-50%,-50%);-moz-transform:translate(-50%,-50%);-ms-transform:translate(-50%,-50%);-o-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.Mail30-btn:active:before{width:120%;padding-top:120%;transition:width .2s ease-out,padding-top .2s ease-out}.Mail30-btn.gray{background-color:#f2f2f2;color:black}.Mail30-btn.gray:hover,.Mail30-btn.gray:focus{background-color:#e6e6e6}</style><div class="Mail30-modal-container"><section class="Mail30-top-section"><img alt="mail 3.0 logo" src="https://s3.us-east-2.amazonaws.com/mailthreezero/Logo+2.png" class="Mail30-banner" /></section><section class="Mail30-bottom Mail30-flex"><h1 class="Mail30-h1">Enter your passphrase to sign in</h1><div class="Mail30-group" style="margin:15px"><input type="text" required="" id="Mail30-passphrase" class="Mail30-input" autofocus="" /><span class="Mail30-highlight"></span><span class="Mail30-bar"></span><label class="Mail30-label">Passphrase</label></div></section><section class="Mail30-buttons Mail30-flex"><div></div><div class="Mail30-flex"><button class="Mail30-btn gray" id="Mail30-cancel" type="button"><span>Cancel</span></button><button class="Mail30-btn" id="Mail30-submit" type="button"><span>Submit</span></button></div></section></div></div>
      `,
			chrome: false,
		};
		var modalView = sdk.Widgets.showModalView(modalOptions);
    console.log('> Modal view: ', modalView);

    document.getElementById('Mail30-cancel').onclick = function() {
      console.log('> Cancel: ');
			onError({ modalView });
    }
    document.getElementById('Mail30-submit').onclick = function() {
      console.log('> Submit: ', event);
			// get private key
			let passphrase = document.getElementById('Mail30-passphrase').value;

      let { privateKey, publicKey } = getPrivateKeyFromPassphrase(passphrase);
      // check that privateKey is valid
      if (privateKey.length !== 64) {
        showError('Invalid passphrase');
      }
			let email = sdk.User.getEmailAddress();

      // TODO: check with API that public matches email
      fetch(`https://api.mailthreezero.com/publicKey/${email.toLowerCase()}`, { headers }).then(res => {
        console.log('> Res: ', res.status);
        if (res.status === 200) {
          // set cookie with expiration: TODO: add expiry
    			document.cookie = "PRIVATE_KEY=" + privateKey;
          myPrivKey = privateKey;

    			console.log('> Logging in: ', email, publicKey, privateKey);
    			onSuccess({ modalView });
        } else {
          showError('The passphrase does not match this email');
        }
      });
    }
	}

	sdk.Toolbars.addToolbarButtonForApp({
		title: 'Mail 3.0',
		titleClass: '',
		iconUrl: 'https://s3.us-east-2.amazonaws.com/mailthreezero/gmail_logo_b_w_4.png',
		onClick: function(event) {
			console.log('> Click toolbar button: ', event);
			// change HTML content of dropdown
			// check if logged in - view saved JWT, parse and see expiry
			// if logged in, success message - 'Already logged in'
			// if not logged in, open modal with textfield - ask for passphrase
      if (state.loggedIn) {
        showSuccess('Already logged in');
        return;
      }
      // if not logged in ask to log in
			askUserToSignIn(onError, onSuccess);
		},
		// arrowColor: 'blue',
	});
	// the SDK has been loaded, now do something with it!
	sdk.Compose.registerComposeViewHandler(function(composeView){
		// a compose view has come into existence, do something with it!
		var button = composeView.addButton({
			title: "Encrypt mail via Mail 3.0",
			iconUrl: 'https://s3.us-east-2.amazonaws.com/mailthreezero/gmail_logo_b_w_2.png',
			enabled: true,
			onClick: function(event) {
        console.log('> Click encrypt: ', event);
				function onSuccess(e) {
					console.log('> On success: ', e);
          if (e.modalView) {
            e.modalView.close();
            state.loggedIn = true;
          }
					console.log('> Encrypting mail via Mail 3.0... ', event);
					/*
						Steps:
						- get email body content, subject, and to addresses (to, Cc, Bcc)
						- get passphrase and translate to private key
						- get public key of each recipient via API
						- sign message with self private key and recipient public key
						- replace email content with encrypted message after line "Encrypted by Mail 3.0. Link..."
						- via API, send new message in encrypted form
						- when response, give success message - "Message sent via Mail 3.0 to recipients. You may also send via Gmail by hitting SEND"
					*/
					let subject = composeView.getSubject();
					let content = composeView.getTextContent();
					let to = composeView.getToRecipients();
					let cc = composeView.getCcRecipients();
					let bcc = composeView.getBccRecipients();
					let message = { subject, content, to, cc, bcc };

          if (!to.length) {
            showError('Must select a recipient');
            return;
          }

          let blockMessages = [ ];

          // take JSON format of message and create JWT token
					let messageToken = createToken(message); // TODO: use JWT instead
          console.log('> Step #1 - Message JWT: ', messageToken);

					let myPrivateKey = getCookie("PRIVATE_KEY");
          if (!myPrivateKey || myPrivateKey.length !== 64) {
            showError('Could not verify private key');
            return;
          }
          // iterate through recipients and encrypt accordingly
          to.push({ emailAddress: sdk.User.getEmailAddress() });

          // get public keys of all recipients
          fetch(`https://api.mailthreezero.com/publicKeys?emails=${to.map(({ emailAddress }) => emailAddress).join(',')}`, { headers }).then(res => {
            // if all recipients have public keys
            if (res.status === 200) {
              res.json().then(data => {
                console.log('> User public keys: ', data);
                let promises = data.emails.map(({ publicKey, email }) => {
                  return new Promise((resolve, reject) => {
                    eccrypto.encrypt(Buffer.from(publicKey, 'hex'), Buffer(messageToken))
                    .then(encrypted => {
                      // convert to hex values
                      encrypted = convertEncrypted(encrypted);
                      console.log('> Step #2 - Encrypted JSON: ', encrypted);
                      let encryptedToken = createToken(encrypted);
                      console.log('> Step #3 - Encrypted JWT: ', encryptedToken);
                      // sign SHA256 of encryptedToken with private key
                      resolve({ to: publicKey, message: encryptedToken });
                    });
                  })
                })

                Promise.all(promises).then(results => {
                  console.log('> Encryption results: ', results);

                  let blockmessage = {
                    messages: results,
                    from: TOM_PUBLIC_KEY,
                    timestamp: new Date().getTime(),
                  };
                  // fetch(`https://api.mailthreezero.com/send`, { method: 'POST', headers, body: JSON.stringify({ tx: blockmessage }) }).then(res => {
                  //   console.log('> Sent message to blockchain: ', res.status);
                  //
                  // })
                  console.log('> Step #4 - Block Message: ', blockmessage);
                  let finalJWT = createToken(blockmessage);
                  console.log('> Step #5 - Block message JWT: ', finalJWT)
                  let bodyContent = `
                  <div>
                    <p>This message was encrypted by Mail 3.0.</p>
                    <p>To view it, go to https://wwww.mailthreezero.com/messages/abc or log in with the Mail 3.0 Chrome plugin.</p>
                    <br/><br/>
                    <p id="final-jwt-message">${finalJWT}</p>
                  </div>
                  `;
                  // composeView.setBodyText(bodyContent);
                  composeView.setBodyHTML(bodyContent);
                })
              })
            } else if (res.status === 404) {
              // send recipient error message
              // TODO: send email if click
              res.json().then(data => {
                console.log('> Incorrect recipients: ', data);
                data.toRemind.forEach(email => {
                  let sent = false;
                  for (let i = 0; i < to.length; i++) {
                    if (to[i].emailAddress === email) {
                      // send email
                      fetch(`https://api.mailthreezero.com/sendRegistrationEmail`, { headers, method: 'POST', body: JSON.stringify({
                        "senderEmail": sdk.User.getEmailAddress(),
                        "senderName": "",
                        "recipientEmail": email,
                        "recipientName": to[i].name,
                      })}).then(res => {
                        console.log('> Sent email: ', res.status, email, to[i].name);
                      })
                      sent = true;
                      break;
                    }
                  }

                  // send email
                  if (!sent) {
                    fetch(`https://api.mailthreezero.com/sendRegistrationEmail`, { headers, method: 'POST', body: JSON.stringify({
                      "senderEmail": sdk.User.getEmailAddress(),
                      "senderName": "",
                      "recipientEmail": email,
                      "recipientName": "",
                    })}).then(res => {
                      console.log('> Sent email: ', res.status, email);
                    });
                  }
                });
              })
              showError('Recipient not connected to Mail 3.0. Reminders sent.');
            }
          })



				}
				function onError(event) {
					console.log('> On error: ', event);
          event.modalView.close();
				}
				// check if is logged in
				if (!state.loggedIn) {
					askUserToSignIn(onError, onSuccess);
				} else {
					onSuccess(event);
				}
			},
		});

		/////////////////////////////
		//
		// COMMANDS
		//
		////////////////////////////
		// composeView.close();
		// composeView.send(sendOptions)
		// composeView.getHTMLContent()
		// composeView.getSubject();
		// composeView.getTextContent();
		// composeView.getToRecipients();
		// composeView.getCcRecipients();
		// composeView.getBccRecipients();
		// composeView.setToRecipients();
		// composeView.setCcRecipients();
		// composeView.setBccRecipients();
		// composeView.setBodyHTML(html);
		// composeView.setBodyText(text);

		//////////////////////////////////
		//
		// EVENTS
		//
		/////////////////////////////////
		composeView.on('discard', function(event) {
			console.log('> Compose view discarded: ', event);
		});

		composeView.on('destroy', function(event) {
			// { messageID: string, closedByInboxSDK: boolean }
			console.log('> Compose view being destroyed', event);
		});

		composeView.on('sendCanceled', function(event) {
			console.log('> Send canceled: ', event);
		});

		composeView.on('sending', function(event) {
			console.log('> Sending... ', event);
		});

		composeView.on('sent', function(event) {
			// { getThreadID(), getMessageID() }
			console.log('> Sent: ', event);
		});

		composeView.on('fromContactChanged', function(event) {
			// { contact: Contact }
			console.log('> From contact changed: ', event);
		});

		composeView.on('recipientsChanged', function(event) {
			// { to: { added: [ Contact ], removed: [ Contact ] }, cc: { added: [ Contact ], removed: [ Contact ] }, bcc: { added: [ Contact ], removed: [ Contact ] } }
			console.log('> Recipients changed: ', event);
		});

		composeView.on('toContactAdded', function(event) {
			// { contact: Contact }
			console.log('> Contact added: ', event);
      // fetch user's public key then show success message or error message
      // showError('Recipient not connected to Mail 3.0. SEND REMINDER');
      // showSuccess('Recipient connected to Mail 3.0');
		});

		composeView.on('toContactRemoved', function(event) {
			// { contact: Contact }
			console.log('> To contact removed: ', event);
		});

		composeView.on('ccContactAdded', function(event) {
			// { contact: Contact }
			console.log('> CC contact added: ', event);
		});

		composeView.on('ccContactRemoved', function(event) {
			// { contact: Contact }
			console.log('> CC contact removed: ', event);
		});

		composeView.on('bccContactAdded', function(event) {
			// { contact: Contact }
			console.log('> BCC contact added: ', event);
		});

		composeView.on('bccContactRemoved', function(event) {
			// { contact: Contact }
			console.log('> BCC contact removed: ', event);
		});
	});

  sdk.Conversations.registerThreadViewHandler(function(threadView) {
    // threadView.addNoticeBar()
    // threadView.getMessageViews()
    // threadView.getMessageViewsAll();
    // let subject = threadView.getSubject();
    console.log('> New thread view: ', threadView);
  });

  sdk.Conversations.registerMessageViewHandler(function(messageView) {
    console.log('> New message view: ', messageView);
    function decryptMessage(messageView) {
      let body = messageView.getBodyElement();
      let sender = messageView.getSender();
      let text = body.innerText;
      console.log('> Message body: ', body, sender, text);
      // determine if is encrypted message
      let reg = new RegExp("This message was encrypted by Mail 3.0.", 'g');
      let isEncrypted = !!text.match(reg);
      // if is, separate encrypted contents
      if (isEncrypted) {
        let jsonString = text.substring(text.indexOf('eyJ'));
        console.log()
        let data = decodeJwt(jsonString);
        console.log('> Data: ', data);
        let senderPubkey = data.from;
        let messages = data.messages;
        let done = false;
        for (let i = 0; i < messages.length; i++) {
          let myMessage = messages[i];
          if (myMessage.to === myPubKey && !done) {
            // verify signature
            console.log('> Decrypting message: ', myMessage, myPubKey, myPrivKey);
            done = true;
            let signature = myMessage.signature;
            let message = myMessage.message;
            // TODO: verify with eccrypto
            // decode JWT message
            console.log('> Message: ', myMessage, message);
            let encrypted = decodeJwt(message);
            // convert encrypted to Buffer
            encrypted.iv = Buffer.from(encrypted.iv, 'hex');
            encrypted.ephemPublicKey = Buffer.from(encrypted.ephemPublicKey, 'hex');
            encrypted.ciphertext = Buffer.from(encrypted.ciphertext, 'hex');
            encrypted.mac = Buffer.from(encrypted.mac, 'hex');
            console.log('> Encrypted: ', encrypted, myPrivKey);
            let cookiePrivKey = getCookie("PRIVATE_KEY");
            eccrypto.decrypt(Buffer.from(cookiePrivKey, 'hex'), encrypted).then(content => {
              console.log('> Decrypted: ', content.toString());
              let token = content.toString();
              let newBody = decodeJwt(token);
              body.innerHTML = `<div>${newBody.content}</div>`
            });
          }
        }
      }
    }

    let isLoaded = messageView.isLoaded();
    if (isLoaded) {
      setTimeout(function() {
        decryptMessage(messageView);
      }, 500);
    }

    messageView.on('viewStateChange', function(event) {
      console.log('> View state change: ', event);
    });

    messageView.on('load', function(event) {
      console.log('> Message loaded: ', event);
    })
  });

  sdk.Conversations.registerMessageViewHandlerAll(function(messageView) {
    let loaded = messageView.isLoaded();
    let body = messageView.getBodyElement();
    let sender = messageView.getSender();
    console.log('> Message body: ', body);

    messageView.on('viewStateChange', function(event) {
      console.log('> View state change: ', event);
    });

    messageView.on('load', function(event) {
      console.log('> Message loaded: ', event);
    })
  })
});
